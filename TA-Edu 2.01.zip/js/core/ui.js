// js/ui.js — Điều khiển menu sidebar trên mobile

document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("menu-toggle");
  const sidebar = document.getElementById("sidebar");

  if (!toggleBtn || !sidebar) return;

  // Bấm ☰ để mở / đóng menu
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
  });

  // 🔹 Chạm ra ngoài để đóng menu (hiệu ứng app thật)
  document.addEventListener("click", (e) => {
    if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
      sidebar.classList.remove("open");
    }
  });
});
.sidebar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar li {
  display: flex;
  align-items: center;
  gap: 10px; /* khoảng cách icon - text */
  font-size: 16px;
  color: #333;
  padding: 10px 16px;
  border-radius: 10px;
  cursor: pointer;
  transition: background 0.3s, transform 0.2s;
}

.sidebar li i {
  width: 22px;
  text-align: center;
  font-size: 18px;
}

.sidebar li:hover {
  background: #e6f6f3;
  transform: translateX(3px);
}

.sidebar li.active {
  background: #2ebfa5;
  color: white;
}

.sidebar li.active i {
  color: white;
}

