// Tự động load header & footer cho mọi trang
async function loadPartial(id, path) {
  const el = document.getElementById(id);
  if (!el) return;
  try {
    const res = await fetch(path);
    el.innerHTML = await res.text();
  } catch (err) {
    console.warn("Không thể tải partial:", path);
  }
}

window.addEventListener("DOMContentLoaded", () => {
  loadPartial("ta-header", "partials/header.html");
  loadPartial("ta-footer", "partials/footer.html");
});
