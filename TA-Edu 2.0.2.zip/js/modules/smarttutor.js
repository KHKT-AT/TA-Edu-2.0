// js/modules/smarttutor.js
import { auth } from "../core/firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";

const chatBox = document.getElementById("chat-box");
const input = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

// 🔑 Thay bằng API key của bạn
const OPENAI_API_KEY = "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";

// Đảm bảo người dùng đã đăng nhập
onAuthStateChanged(auth, (user) => {
  if (!user) {
    window.location.href = "/login.html";
  } else {
    appendMessage("bot", `Xin chào ${user.displayName || "bạn"} 👋! Mình là SmartTutor, hãy hỏi mình bất kỳ điều gì về bài học nhé.`);
  }
});

// Gửi tin nhắn khi người dùng nhấn Enter hoặc nút Gửi
sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keypress", (e) => {
  if (e.key === "Enter") sendMessage();
});

// --------------------------
// 🧩 GỬI TIN NHẮN CHO AI
// --------------------------
async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;

  appendMessage("user", text);
  input.value = "";

  appendMessage("bot", "⏳ Đang suy nghĩ...");

  const reply = await askAI(text);
  const loading = chatBox.querySelector(".bot-msg:last-child");
  if (loading) loading.remove();

  appendMessage("bot", reply);
}

// --------------------------
// 🧠 GỌI API CHATGPT
// --------------------------
async function askAI(prompt) {
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Bạn là SmartTutor - trợ lý học tập thông minh, nói tiếng Việt, thân thiện, chuyên giải thích kiến thức dễ hiểu cho học sinh." },
          { role: "user", content: prompt }
        ],
        temperature: 0.8
      })
    });

    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content || "Xin lỗi, mình chưa hiểu rõ câu hỏi này.";
    return answer;
  } catch (error) {
    console.error(error);
    return "⚠️ Có lỗi xảy ra khi kết nối AI. Vui lòng thử lại sau!";
  }
}

// --------------------------
// 💬 HIỂN THỊ TIN NHẮN
// --------------------------
function appendMessage(sender, msg) {
  const div = document.createElement("div");
  div.className = sender === "user" ? "user-msg" : "bot-msg";
  div.textContent = msg;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}
