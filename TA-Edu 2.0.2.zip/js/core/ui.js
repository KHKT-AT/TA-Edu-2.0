// js/ui.js — Điều khiển menu sidebar trên mobile

document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("menu-toggle");
  const sidebar = document.getElementById("sidebar");

  if (!toggleBtn || !sidebar) return;

  // Bấm ☰ để mở / đóng menu
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
  });

  // 🔹 Chạm ra ngoài để đóng menu (hiệu ứng app thật)
  document.addEventListener("click", (e) => {
    if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
      sidebar.classList.remove("open");
    }
  });
});
