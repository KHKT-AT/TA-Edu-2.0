// js/core/role.js
import {
  auth,
  db,
  onAuthStateChanged
} from "./firebase.js";
import {
  doc,
  getDoc,
  updateDoc
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";

// Khi trang được tải
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "/login.html";
    return;
  }

  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  const data = snap.data();

  // ✅ Kiểm tra phần tử tồn tại trước khi thay text
  const nameEl = document.getElementById("role-name");
  if (nameEl) {
    nameEl.textContent = data.displayName || user.displayName || "Người dùng";
  }

  // Gắn sự kiện chọn vai trò
  const btnStudent = document.getElementById("student-btn");
  const btnTutor = document.getElementById("tutor-btn");

  if (btnStudent) {
    btnStudent.onclick = () => updateRole(ref, "Học sinh");
  }
  if (btnTutor) {
    btnTutor.onclick = () => updateRole(ref, "Gia sư");
  }
});

// Cập nhật vai trò người dùng trong Firestore
async function updateRole(ref, role) {
  const box = document.querySelector(".role-container");
  try {
    box.classList.add("saving");
    box.innerHTML = `<h2>Đang lưu vai trò của bạn... ⏳</h2>`;
    await updateDoc(ref, { role });
    setTimeout(() => {
      window.location.href = "/dashboard.html";
    }, 1000);
  } catch (err) {
    console.error(err);
    alert("Lỗi khi cập nhật vai trò.");
  }
}
