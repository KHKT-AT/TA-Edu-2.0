// =============================================
// 🔹 TA-Edu Boot Header (Final Improved Version)
// Quản lý header, đăng nhập, avatar & điều hướng dashboard
// =============================================

import {
  auth,
  provider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from "./firebase.js";

(async () => {
  // ----- Tải file header -----
  async function fetchText(url) {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) throw new Error("Không thể tải " + url);
    return await res.text();
  }

  // Xác định đường dẫn gốc
  const base = new URL(import.meta.url).href.replace(/js\/core\/boot_header\.js$/, "");

  // Nạp partial header
  const html = await fetchText(`${base}partials/header.html`);
  const wrap = document.createElement("div");
  wrap.innerHTML = html.trim();

  // Cập nhật đường dẫn tương đối
  wrap.querySelectorAll("[data-href]").forEach((a) => (a.href = base + a.dataset.href));
  wrap.querySelectorAll("[data-src]").forEach((img) => (img.src = base + img.dataset.src));

  // Thêm header vào đầu trang
  document.body.insertBefore(wrap.firstElementChild, document.body.firstChild);

  // ==============================
  // 🔸 Gán phần tử
  // ==============================
  const btnLogin = document.getElementById("btnLogin");
  const userInfo = document.getElementById("userInfo");
  const userPhoto = document.getElementById("userPhoto");
  const userMenu = document.getElementById("userMenu");
  const btnLogout = document.getElementById("btnLogout");
  const dashboardLink = document.querySelector('a[data-href="dashboard.html"]');

  // ==============================
  // 🔸 Đăng nhập Google
  // ==============================
  btnLogin?.addEventListener("click", async () => {
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Lỗi đăng nhập:", err);
      alert("Không thể đăng nhập. Vui lòng thử lại!");
    }
  });

  // ==============================
  // 🔸 Toggle dropdown khi click avatar
  // ==============================
  userPhoto?.addEventListener("click", (e) => {
    e.stopPropagation();
    userMenu.classList.toggle("show");
  });

  // Click ra ngoài → đóng menu
  document.addEventListener("click", (e) => {
    if (!userInfo.contains(e.target)) {
      userMenu.classList.remove("show");
    }
  });

  // ==============================
  // 🔸 Đăng xuất
  // ==============================
  btnLogout?.addEventListener("click", async () => {
    await signOut(auth);
    userMenu?.classList.remove("show");
  });

  // ==============================
  // 🔸 Theo dõi trạng thái Auth
  // ==============================
  onAuthStateChanged(auth, (user) => {
    if (user) {
      // ✅ Đã đăng nhập
      btnLogin.style.display = "none";
      userInfo.style.display = "flex";
      if (dashboardLink) dashboardLink.style.display = "none"; // Ẩn Dashboard trên menu

      const avatar = user.photoURL || "assets/default_avatar.png";
      userPhoto.src = avatar;

      // Cập nhật thông tin trong menu dropdown
      document.getElementById("menuName").textContent = user.displayName || "Người dùng";
      document.getElementById("menuWallet").textContent = `Số dư ví: ${user.wallet || 0}₫`;
    } else {
      // ❌ Chưa đăng nhập
      btnLogin.style.display = "inline-flex";
      userInfo.style.display = "none";
      if (dashboardLink) dashboardLink.style.display = "none";
    }
  });
})();
