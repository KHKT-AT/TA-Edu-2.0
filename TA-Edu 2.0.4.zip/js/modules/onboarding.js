// js/modules/onboarding.js
// Onboarding TA-Edu 2.x: chọn role + điền form + nộp KYC
// Lưu ý: chạy offline vẫn ổn (mock localStorage); nếu có Firebase sẽ ghi Firestore & Storage.

import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import {
  getFirestore, doc, setDoc, serverTimestamp, updateDoc
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";
import {
  getStorage, ref, uploadBytes, getDownloadURL
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-storage.js";

// ========== helper ==========
const $  = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
const show = (step) => {
  $$('[data-step]').forEach(el => el.hidden = el.getAttribute('data-step') !== step);
  history.replaceState(null, '', `#step=${step}`);
};
function toast(msg){ alert(msg); }
function fileOrNull(input){ return (input?.files && input.files[0]) ? input.files[0] : null; }
function val(form, name){ return form.elements[name]?.value?.trim() || ""; }

// mock localStorage key theo uid
const key = (uid) => (n) => `taedu_onboarding:${uid}:${n}`;

// ========== firebase safe access ==========
let auth=null, db=null, storage=null, user=null;
try {
  auth = getAuth();
  db = getFirestore();
  storage = getStorage();
} catch { /* offline mock */ }

// ========== main ==========
document.addEventListener('DOMContentLoaded', () => {
  // điều hướng theo hash
  const step = new URL(location.href).hash.split('=')[1] || 'select';
  show(step);

  // nav nút quay lại
  $$('[data-back]').forEach(b => b.addEventListener('click', () => show('select')));

  // chọn role
  $$('.ob__role').forEach(btn => {
    btn.addEventListener('click', () => {
      const role = btn.dataset.role;
      localStorage.setItem('taedu_role_choice', role);
      show(role);
    });
  });

  // auth -> bind forms
  if (auth) {
    onAuthStateChanged(auth, async (u) => {
      user = u;
      if (!u) { toast('Vui lòng đăng nhập để tiếp tục.'); location.href = 'index.html'; return; }
      bindStudent();
      bindTutor();
      // nếu đã nộp trước đó
      const savedStep = localStorage.getItem(key(u.uid)('lastStep'));
      if (savedStep && ['submitted'].includes(savedStep)) show(savedStep);
    });
  } else {
    // offline vẫn cho test
    user = { uid: 'local', email: 'local@example.com', displayName: 'Local User' };
    bindStudent(); bindTutor();
  }
});

// ========== upload helpers ==========
async function putFile(path, file){
  if (!storage || !file) return null;
  const r = ref(storage, path);
  await uploadBytes(r, file);
  return await getDownloadURL(r);
}

// ========== STUDENT ==========
function bindStudent(){
  const form = $('#formStudent');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = val(form,'name'), dob=val(form,'dob'), phone=val(form,'phone'),
          grade=val(form,'grade'), address=val(form,'address'),
          pName=val(form,'parent_name'), pEmail=val(form,'parent_email'), pPhone=val(form,'parent_phone');
    const fFront = fileOrNull(form.elements['cccd_front']);
    const fBack  = fileOrNull(form.elements['cccd_back']);
    if (!name||!dob||!cccd||!phone||!fFront||!fBack||!fSelf||!subjects||levels.length === 0) {
    return toast('Vui lòng điền đủ thông tin và chọn ít nhất 1 lớp dạy (10/11/12).');
    }
    try {
      // upload
      const base = `kyc/${user.uid}`;
      const urlFront = await putFile(`${base}/cccd_front.jpg`, fFront);
      const urlBack  = await putFile(`${base}/cccd_back.jpg`,  fBack);

      const payload = {
        role: 'student',
        verify: { status: 'submitted', submittedAt: Date.now(), reviewNote: '' },
        profile: { name, dob, phone, grade, address },
        parent : { name: pName, email: pEmail, phone: pPhone },
        kyc: { cccd_front: urlFront, cccd_back: urlBack }
      };

      if (db) {
        // tạo/ghi user doc
        await setDoc(doc(db, 'users', user.uid), {
          email: user.email || null,
          displayName: user.displayName || null,
          createdAt: serverTimestamp(),
          ...payload
        }, { merge: true });
      } else {
        // mock offline
        localStorage.setItem(key(user.uid)('student_payload'), JSON.stringify(payload));
      }

      localStorage.setItem(key(user.uid)('lastStep'), 'submitted');
      show('submitted');
    } catch (err) {
      console.error(err); toast('Không thể gửi hồ sơ. Thử lại sau.');
    }
  });
}

// ========== TUTOR ==========
function bindTutor(){
  const form = $('#formTutor');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name=val(form,'name'), dob=val(form,'dob'), cccd=val(form,'cccd'), phone=val(form,'phone'),
      address=val(form,'address'), subjects=val(form,'subjects'),
      bio=val(form,'bio');
    const levelEls = form.querySelectorAll('input[name="levels[]"]:checked');
    const levels = Array.from(levelEls).map(el => el.value);
    const fFront=fileOrNull(form.elements['cccd_front']);
    const fBack =fileOrNull(form.elements['cccd_back']);
    const fSelf =fileOrNull(form.elements['selfie']);
    const fCerts=form.elements['certs']?.files || [];
    if (!name||!dob||!cccd||!phone||!fFront||!fBack||!fSelf||!subjects||!levels) return toast('Vui lòng điền đủ thông tin bắt buộc.');

    try {
      const base = `kyc/${user.uid}`;
      const urlFront = await putFile(`${base}/cccd_front.jpg`, fFront);
      const urlBack  = await putFile(`${base}/cccd_back.jpg`,  fBack);
      const urlSelf  = await putFile(`${base}/selfie.jpg`,      fSelf);

      const certUrls = [];
      if (storage && fCerts.length) {
        for (let i=0;i<fCerts.length;i++){
          const u = await putFile(`${base}/cert_${i+1}.${getExt(fCerts[i].name)}`, fCerts[i]);
          if (u) certUrls.push(u);
        }
      }

      const payload = {
        role: 'tutor',
        verify: { status: 'submitted', submittedAt: Date.now(), reviewNote: '' },
        profile: { name, dob, phone, address, cccd },
        tutor: { subjects, levels, bio, certificates: certUrls },
        kyc: { cccd_front: urlFront, cccd_back: urlBack, selfie: urlSelf }
      };

      if (db) {
        await setDoc(doc(db, 'users', user.uid), {
          email: user.email || null,
          displayName: user.displayName || null,
          createdAt: serverTimestamp(),
          ...payload
        }, { merge: true });
      } else {
        localStorage.setItem(key(user.uid)('tutor_payload'), JSON.stringify(payload));
      }

      localStorage.setItem(key(user.uid)('lastStep'), 'submitted');
      show('submitted');
    } catch (err) {
      console.error(err); toast('Không thể gửi hồ sơ. Thử lại sau.');
    }
  });
}

function getExt(name){ const m = name?.match(/\.([a-z0-9]+)$/i); return m?m[1]:'bin'; }
