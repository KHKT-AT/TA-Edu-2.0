// js/core/firebase.js
// Khởi tạo Firebase cho TA-Edu

// Import từ CDN Firebase Web SDK dạng module hiện đại
// (chúng ta chỉ import những thứ cần dùng: app, auth, firestore, storage) :contentReference[oaicite:2]{index=2}
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  signInWithPopup,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";
import {
  getStorage
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-storage.js";

// TODO: Dán config thật của bạn từ Firebase console vào đây
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAaXumzkgOlIvb76J_bFXa28S51lyfimew",
  authDomain: "ta-edu-nh.firebaseapp.com",
  projectId: "ta-edu-nh",
  storageBucket: "ta-edu-nh.firebasestorage.app",
  messagingSenderId: "342673903321",
  appId: "1:342673903321:web:a7a2e58d79347c9ae0b8c8",
  measurementId: "G-XZ90FNSZEQ"
};

// Khởi tạo app
const app = initializeApp(firebaseConfig);

// Core services
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const db = getFirestore(app);
const storage = getStorage(app);

// Hàm tiện ích: đảm bảo user đã có document trong Firestore
// Khi user đăng nhập lần đầu, ta tạo hồ sơ cơ bản
async function ensureUserProfile(user) {
  if (!user) return;

  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    await setDoc(ref, {
      uid: user.uid,
      displayName: user.displayName || "",
      email: user.email || "",
      role: "Học sinh",
      wallet: 0,
      reputation: 0,
      createdAt: Date.now()
    });
  }
}

// Xuất ra để file khác dùng
export {
  app,
  auth,
  provider,
  db,
  storage,
  ensureUserProfile,
  signInWithEmailAndPassword,
  signInWithPopup,
  onAuthStateChanged,
  signOut
};
