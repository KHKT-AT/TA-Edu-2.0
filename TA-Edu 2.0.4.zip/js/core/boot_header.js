// =============================================
// TA-Edu | Core - Boot Header (Clean & Safe)
// - Nạp header
// - Đăng nhập/đăng xuất Google
// - Dropdown avatar (click ra ngoài / ESC để đóng)
// - Avatar dự phòng SVG, tránh 404
// - Phát 'taedu:header:ready' để module khác gắn sau
// =============================================
import { auth, provider, signInWithPopup, signOut, onAuthStateChanged } from "./firebase.js";

const FALLBACK_AVATAR = "assets/default_avatar.svg";

(async () => {
  // --- helper ---
  async function fetchText(url) {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) throw new Error("Không thể tải " + url);
    return res.text();
  }

  // 1) Nạp partial header
  const base = new URL(import.meta.url).href.replace(/js\/core\/boot_header\.js$/, "");
  const html = await fetchText(`${base}partials/header.html`);
  const wrap = document.createElement("div");
  wrap.innerHTML = html.trim();

  // nếu header.html dùng data-href/data-src thì map lại, không có cũng không sao
  wrap.querySelectorAll("[data-href]").forEach(a => a.href = base + a.dataset.href);
  wrap.querySelectorAll("[data-src]").forEach(img => img.src = base + img.dataset.src);

  const headerEl = wrap.firstElementChild;
  document.body.insertBefore(headerEl, document.body.firstChild);

  // 2) DOM refs (sau khi đã gắn header vào body)
  const btnLogin  = document.getElementById("btnLogin");
  const userInfo  = document.getElementById("userInfo");
  const userPhoto = document.getElementById("userPhoto");
  const userMenu  = document.getElementById("userMenu");
  const btnLogout = document.getElementById("btnLogout");
  const dashboardLink = document.querySelector('a[href="dashboard.html"], a[data-href="dashboard.html"]');

  // 3) tiện ích
  const show = el => el && (el.hidden = false);
  const hide = el => el && (el.hidden = true);

  function updateAvatar(src) {
    document.querySelectorAll('[data-avatar], .header-avatar, #userPhoto, #user-avatar')
      .forEach(img => {
        img.src = src || FALLBACK_AVATAR;
        img.onerror = () => (img.src = FALLBACK_AVATAR);
      });
  }

  // 4) sự kiện menu avatar
  userPhoto?.addEventListener("click", (e) => {
    e.stopPropagation();
    userMenu?.classList.toggle("show");
  });
  document.addEventListener("click", (e) => {
    if (userInfo && !userInfo.contains(e.target)) userMenu?.classList.remove("show");
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") userMenu?.classList.remove("show");
  });

  // 5) đăng nhập / đăng xuất
  btnLogin?.addEventListener("click", async () => {
    try { await signInWithPopup(auth, provider); }
    catch (err) { console.error(err); alert("Không thể đăng nhập. Vui lòng thử lại!"); }
  });
  btnLogout?.addEventListener("click", async () => {
    try { await signOut(auth); } finally { userMenu?.classList.remove("show"); }
  });

  // 6) theo dõi trạng thái đăng nhập (chỉ 1 khối)
  function setAuthUI(isAuth) {
    // class trên body để CSS phụ trợ
    document.body.classList.toggle("is-auth", isAuth);

    // btnLogin
    if (btnLogin) {
      btnLogin.hidden = isAuth;
      btnLogin.style.display = isAuth ? "none" : "";
    }
    // userInfo (khối avatar + menu)
    if (userInfo) {
      userInfo.hidden = !isAuth;
      if (!isAuth) userMenu?.classList.remove("show");
    }
  }

  onAuthStateChanged(auth, (user) => {
  window.__TAEDU_LAST_USER = user || null;
  window.dispatchEvent(new CustomEvent('taedu:user-ready', { detail: { user } }));
    const isAuth = !!user;
    setAuthUI(isAuth);

    if (isAuth) {
      updateAvatar(user.photoURL);
      const nameEl   = document.getElementById("menuName");
      const walletEl = document.getElementById("menuWallet");
      if (nameEl)   nameEl.textContent   = user.displayName || "Người dùng";
      if (walletEl) walletEl.textContent = `Số dư ví: ${user.wallet || 0}₫`;
      if (dashboardLink) dashboardLink.style.display = "";
    } else {
      updateAvatar(FALLBACK_AVATAR);
      if (dashboardLink) dashboardLink.style.display = "none";
    }
  });

  // 7) thông báo cho module khác biết header đã sẵn sàng
  document.dispatchEvent(new CustomEvent("taedu:header:ready", { detail: { header: headerEl } }));

  // ======= 8) Avatar sáng khi đang ở Dashboard =======
  function highlightDashboard() {
    const file = location.pathname.split('/').pop().toLowerCase() || 'index.html';
    if (file === 'dashboard.html') {
      document.querySelectorAll('header .active, header .is-active')
        .forEach(el => el.classList.remove('active', 'is-active'));
      userPhoto?.classList.add('is-current');
    } else {
      userPhoto?.classList.remove('is-current');
    }
  }

  highlightDashboard();

  // ======= 9) Menu chính sáng theo trang =======
  function highlightCurrentMenu() {
    const currentFile = location.pathname.split('/').pop().toLowerCase() || 'index.html';
    const navLinks = document.querySelectorAll('.main-nav a');

    navLinks.forEach(link => {
      link.classList.remove('active', 'is-active');
      const linkFile = link.getAttribute('href')?.split('/').pop().toLowerCase();
      if (linkFile === currentFile) {
        link.classList.add('active');
      }
    });
  }

  highlightCurrentMenu();
})();
