// js/core/role.js
import { auth, onAuthStateChanged, db } from "./firebase.js";

// Nếu bạn chưa export db trong firebase.js thì db === undefined -> vẫn chạy bằng localStorage
let selectedRole = null;

const nameEl     = document.getElementById("role-name");
const btnStudent = document.getElementById("student-btn");
const btnTutor   = document.getElementById("tutor-btn");
const container  = document.querySelector(".role-container");
const ROLE_MAP   = { student: "Học sinh", tutor: "Gia sư" };

// Helper Firestore (nếu có)
let fs = null;
async function ensureFS() {
  if (!db || fs) return;
  fs = await import("https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js");
}

function setSelected(roleKey) {
  selectedRole = roleKey;
  // Bật state UI nếu bạn dùng aria-pressed:
  [btnStudent, btnTutor].forEach(btn => {
    if (!btn) return;
    const isMe = btn.id === (roleKey === "student" ? "student-btn" : "tutor-btn");
    btn?.setAttribute?.("aria-pressed", isMe ? "true" : "false");
  });
  // Bật nút tiếp tục nếu bạn có nút riêng (ở bản của bạn là bấm thẳng từng vai):
  // document.getElementById("btnContinue")?.removeAttribute("disabled");
}

async function getExistingRole(uid) {
  // Ưu tiên Firestore nếu có
  try {
    if (db) {
      await ensureFS();
      const { doc, getDoc } = fs;
      const ref = doc(db, "users", uid);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const data = snap.data();
        return data?.role || null;
      }
    }
  } catch (e) {
    console.warn("[TA-Edu] Không đọc được role từ Firestore:", e);
  }
  // Fallback localStorage
  return localStorage.getItem("taedu_role");
}

async function setRole(uid, key) {
  // Lưu Firestore nếu có, luôn kèm fallback localStorage
  localStorage.setItem("taedu_role", key);
  if (!db) return; // chưa cấu hình Firestore -> chỉ dùng LS

  await ensureFS();
  const { doc, setDoc } = fs;
  const ref = doc(db, "users", uid);
  await setDoc(ref, { role: key, roleLabel: ROLE_MAP[key] || "Học sinh" }, { merge: true });
}

function redirectToDashboard() {
  window.location.href = "dashboard.html";
}

function lockUI(on, msg = "Đang lưu vai trò của bạn... ⏳") {
  if (!container) return;
  if (on) {
    container.classList.add("saving");
    container.setAttribute("aria-busy", "true");
    container.style.pointerEvents = "none";
    container.style.opacity = "0.6";
  } else {
    container.classList.remove("saving");
    container.removeAttribute("aria-busy");
    container.style.pointerEvents = "";
    container.style.opacity = "";
  }
}

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }

  // Hiển thị tên
  if (nameEl) nameEl.textContent = user.displayName || "Người dùng";

  // Pre-select role nếu đã có
  const existing = await getExistingRole(user.uid);
  if (existing && (existing === "student" || existing === "tutor")) {
    setSelected(existing);
  }

  // Bind chọn vai
  if (btnStudent) btnStudent.onclick = async () => {
    try {
      lockUI(true);
      await setRole(user.uid, "student");
      redirectToDashboard();
    } catch (e) {
      console.error(e);
      alert("Lưu vai trò thất bại. Vui lòng thử lại.");
    } finally {
      lockUI(false);
    }
  };

  if (btnTutor) btnTutor.onclick = async () => {
    try {
      lockUI(true);
      await setRole(user.uid, "tutor");
      redirectToDashboard();
    } catch (e) {
      console.error(e);
      alert("Lưu vai trò thất bại. Vui lòng thử lại.");
    } finally {
      lockUI(false);
    }
  };
});
