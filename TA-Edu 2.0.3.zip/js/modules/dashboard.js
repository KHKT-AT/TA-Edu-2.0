// js/modules/dashboard.js
import { auth, onAuthStateChanged, signOut } from '../core/firebase.js';

const $  = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];

const FALLBACK = 'assets/default_avatar.svg';

// ----- Hash <-> tab -----
function getTabFromHash() {
  const m = location.hash.match(/tab=([a-z0-9_-]+)/i);
  return m ? m[1] : 'profile';
}
function setHash(tab) {
  history.replaceState(null, '', `#tab=${tab}`);
}

// ----- Active UI -----
function activateTab(tab) {
  // Panel
  $$('.panel').forEach(p => p.classList.toggle('is-active', p.id === `tab-${tab}`));
  // Nav
  $$('.dash__nav .nav-item').forEach(a => a.classList.toggle('is-active', a.dataset.tab === tab));
  setHash(tab);
}

function bindNav() {
  $$('.dash__nav .nav-item').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      activateTab(a.dataset.tab);
    });
  });
  window.addEventListener('hashchange', () => activateTab(getTabFromHash()));
}

// ----- Actions -----
function bindLogout() {
  $('#dashLogout')?.addEventListener('click', async () => {
    try { await signOut(auth); location.href = 'index.html'; }
    catch (e) { console.error(e); alert('Đăng xuất thất bại, thử lại nhé.'); }
  });
}

// ----- Fill data -----
const fmt = n => ((+n||0).toLocaleString('vi-VN') + '₫');

function fillUser(u) {
  const photo = u?.photoURL || FALLBACK;
  const name  = u?.displayName || 'Người dùng';
  const mail  = u?.email || 'email@example.com';
  const role  = (localStorage.getItem('taedu_role') === 'tutor') ? 'Gia sư' : 'Học sinh';
  const wal   = u?.wallet ?? 0;

  // Sidebar
  $('#dashAvatar') && ($('#dashAvatar').src = photo);
  $('#dashName')?.replaceChildren(name);
  $('#dashEmail')?.replaceChildren(mail);
  $('#dashRole')?.replaceChildren(role);

  // Profile
  $('#profileAvatar') && ($('#profileAvatar').src = photo);
  $('#profileName')?.replaceChildren(name);
  $('#profileEmail')?.replaceChildren(mail);
  $('#profileRole')?.replaceChildren(role);

  // Wallet
  $('#walletAmount')?.replaceChildren(fmt(wal));
}

// ----- Init -----
document.addEventListener('DOMContentLoaded', () => {
  bindNav();
  bindLogout();

  activateTab(getTabFromHash());

  onAuthStateChanged(auth, (user) => {
    if (!user) { location.href = 'index.html'; return; }
    fillUser(user);
  });
});
