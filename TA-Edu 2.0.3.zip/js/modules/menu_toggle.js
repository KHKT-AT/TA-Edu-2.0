// /js/modules/menu_toggle.js
// Toggle mở/đóng menu mobile (tách JS riêng theo chuẩn dự án)

document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.taedu-nav');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', () => {
    const opened = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(opened));
  });
});
